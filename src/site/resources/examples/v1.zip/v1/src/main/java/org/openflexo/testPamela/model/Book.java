/*
 * A book pamela model
 */
package org.openflexo.testPamela.model;

import org.openflexo.pamela.annotations.*;

@ModelEntity
public interface Book {

  @Initializer
  Book init(@Parameter("title")String aTitle);

  @Getter("title")
  String getTitle();

  @Setter("title")
  void setTitle(String aTitle);

  @Getter("ISBN")
  String getISBN();

  @Setter("ISBN")
  void setISBN(String value);
}
