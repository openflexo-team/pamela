/*
 * A book pamela model
 */
package org.openflexo.testPamela.model;

import org.openflexo.pamela.annotations.*;

@ModelEntity
@ImplementationClass(Book.BookImpl.class)
public interface Book {

  @Initializer
  Book init(@Parameter("title")String aTitle);

  @Getter("title")
  String getTitle();

  @Setter("title")
  void setTitle(String aTitle);

  @Getter("ISBN")
  String getISBN();

  @Setter("ISBN")
  void setISBN(String value);

  boolean isCorrect();

  // Provides a partial implementation for Book
  static abstract class BookImpl implements Book {
    @Override
    public String toString() {
      String title = getTitle();
      String isbn = getISBN();
      return "Book(" + title + "," + isbn + ")";
    }

    public boolean isCorrect() {
        return getTitle() != null && getISBN() != null;
    }
  }
}
