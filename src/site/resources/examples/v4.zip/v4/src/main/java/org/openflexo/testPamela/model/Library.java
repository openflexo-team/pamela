/*
 * A book pamela model
 */
package org.openflexo.testPamela.model;

import org.openflexo.pamela.annotations.*;
import org.openflexo.pamela.annotations.Getter.Cardinality;
import org.openflexo.pamela.AccessibleProxyObject;

import java.util.List;

@ModelEntity
@ImplementationClass(Library.LibraryImpl.class)
public interface Library extends AccessibleProxyObject {

  static String BOOKS = "books";

  @Getter(value = BOOKS, cardinality = Cardinality.LIST)
  List<Book> getBooks();

  @Adder(BOOKS)
  void addToBooks(Book aBook);

  @Remover(BOOKS)
  void removeFromBooks(Book aBook);

  @Reindexer(BOOKS)
  void moveBookToIndex(Book aBook, int index);

  @Finder(collection = BOOKS, attribute = "title")
  Book getBook(String title);

  // Provides a partial implementation for Book
  static abstract class LibraryImpl implements Library {
    @Override
    public String toString() {
      StringBuilder str = new StringBuilder("[");
      boolean first =true;
      for (Book b : getBooks()) {
        if (!first) {
          str.append(",");
        }
        str.append(b);
      }
      str.append("]");
      return str.toString();
    }
  }
}
