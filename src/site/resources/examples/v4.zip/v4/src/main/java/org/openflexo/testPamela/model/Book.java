/*
 * A book pamela model
 */
package org.openflexo.testPamela.model;

import org.openflexo.pamela.annotations.*;
import org.openflexo.pamela.AccessibleProxyObject;

@ModelEntity
@ImplementationClass(Book.BookImpl.class)
public interface Book extends AccessibleProxyObject {

  static final String TITLE = "title";
  static final String ISBN = "ISBN";

  @Initializer
  Book init(@Parameter(TITLE)String aTitle);

  @Getter(TITLE)
  String getTitle();

  @Setter(TITLE)
  void setTitle(String aTitle);

  @Getter(ISBN)
  String getISBN();

  @Setter(ISBN)
  void setISBN(String value);

  boolean isCorrect();

  // Provides a partial implementation for Book
  static abstract class BookImpl implements Book {
    @Override
      public String getISBN() {
        String isbn = (String) performSuperGetter(ISBN);
        if (isbn == null) {
          return "Unknown";
        }
        return isbn;
    }

    @Override
    public String toString() {
      String title = getTitle();
      String isbn = getISBN();
      return "Book(" + title + "," + isbn + ")";
    }

    public boolean isCorrect() {
        return getTitle() != null && getISBN() != null;
    }
  }
}
